import java.util.Scanner;

public class Quiz02_02
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("정수를 입력해 주세요 :");
		while (!sc.hasNextInt()) {
			sc.next();
			System.err.println("에러! 숫자가 아닙니다.");
			System.out.print("재 선택 : ");
		}
		int num = sc.nextInt();
		int result=1;
		for (int i = 1; i < num; i++)
		{
			result *=num; 
		}
		System.out.println(result);
	}


}
