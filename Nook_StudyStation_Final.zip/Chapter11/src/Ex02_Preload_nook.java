import java.util.Random;


public class Ex02_Preload_nook
{
//	int num;
	
	public static void main(String[] args)
	{
		System.out.println(Num.num); 
		Random rand= new Random();
		num=rand.nextInt(100);
		System.out.println(num);
	}

}
