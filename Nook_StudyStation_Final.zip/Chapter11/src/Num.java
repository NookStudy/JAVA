
public class Num
{
	int num;
}
