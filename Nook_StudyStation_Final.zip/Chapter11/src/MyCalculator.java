
public class MyCalculator
{
	public static int adder(int n1, int n2)
	{
		return n1 + n2;
		
	}
	
}
