
public class Ex03_Boolean
{

	public static void main(String[] args)
	{
		boolean check1 = true;
		boolean check2 = false;
		boolean check3 = (1<2);
		boolean check4 = (1+2==4);
		
		
		System.out.println(check1);
		System.out.println(check2);
		System.out.println(check3);
		System.out.println(check4);
		System.out.println(1>2);
	}

}
