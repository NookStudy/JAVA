
public class Ex02_Char
{

	public static void main(String[] args)
	{
		char ch1 = 'A';		// 문자하나.
		char ch2 = 65;		// 아스키 코드의 65 입력
		char ch3 = 0x41;	// 16진수로 문자값 직접 입력
		char ch4 = 0b0000000001000001;//2진수로 문자값 직접 입력

	System.out.println(ch1);
	System.out.println(ch2);
	System.out.println(ch3);
	System.out.println(ch4);
	/*
	 * 아스키 코드 : 1ybe롤 표한할수 있는 문자 (숫자,영어
	 * 유니코드 : 2byte로 표현(영어 숫자 한글 일본어 중국어 etc
	 */
	}
}
