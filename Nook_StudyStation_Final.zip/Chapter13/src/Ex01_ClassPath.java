import java.util.Date;

public class Ex01_ClassPath
{

	public static void main(String[] args)
	{
		Apple apple = new Apple();
		apple.showName();
		
		Date d = new Date();
		
	}

}
