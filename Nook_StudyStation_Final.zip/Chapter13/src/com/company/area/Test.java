package com.company.area;

public class Test
{
	public void testPrint() {
		System.out.println("check");
	}
}
