class {
	@Override
	public void String toString() {
		return String;
	}
}


public class Nook_Overiding
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}
