class BoxA{
	public int a;
	
	BoxA(int[] a,int b){
		int[] ar = new int[b];
	}
}


public class Nook_Boxarray
{

	public static void main(String[] args)
	{
		int[] s = new int[3];
		
//		BoxA[] ar = {Box c = new BoxA(s,2)};
		//객체 배열생성
		
//		ar[0] = new BoxA(1);

	}

}
