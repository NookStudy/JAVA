class Hotel{
	int floor;
	int roomNum;
	String name;
	public Hotel(int[] a, String name) {}
	public Hotel() {}

	

}
public class Hotel_California
{

	public static void main(String[] args)
	{
		int[] arr = new int[3];
		Hotel california = new Hotel(arr, "전우치" );
		
		System.out.println(california);
		
		
		
	
	}	
}

