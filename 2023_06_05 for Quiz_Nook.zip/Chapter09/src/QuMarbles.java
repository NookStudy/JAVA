/*
 * 구슬치기 추상화.
 * -보유구슬 갯수, 획득 , 상실, 현재보유갯수 표현.
 * 초기화: 어린이1 :20 2:15
 * 
 * 1게임 1이 2의 구슬 5개획득
 * 2게임 2가 1의 구슬 9개획득
 * 객체생성시 구슬보유갯수는 생성자를 통해 초기화되어야 함.
 */

public class QuMarbles
{

	public static void main(String[] args)
	{
		ChildProperty child1 = new ChildProperty(20);
		ChildProperty child2 = new ChildProperty(15);

		System.out.println("게임 전 구슬의 보유 개수");
		System.out.print("어린이1 : ");
		child1.showProperty(); 
		System.out.print("어린이2 : ");
		child2.showProperty(); 

		/*1차게임 : 어린이1은 어린이2의 구슬 5개 획득*/
		child1.obtainBead(child2, 5);

		/*2차게임 : 어린이2가 어린이1의 구슬 9개 획득*/
		child2.obtainBead(child1, 9);

		System.out.println("\n게임 후 구슬의 보유 개수");
		System.out.print("어린이1 : ");
		child1.showProperty(); 
		System.out.print("어린이2 : ");
		child2.showProperty();


	}

}
