class Camp8<T extends Number>
{
	private T ob;
	
	public void set(T o) {
		ob = o;
	}
	public T get() {
		return ob;
	}
	
	public int toIntValue()
	{
		return ob.intValue(); //extends Numbber 안사용하면 여기서 에러가 남.
	}
}
public class Ex08_BoundedCamp
{

	public static void main(String[] args)
	{
		Camp8<Integer> iBox = new Camp8<>();
		iBox.set(24);
		Camp8<Double> dBox = new Camp8<>();
		dBox.set(5.97);
		Camp8<Number> nBox = new Camp8<>();
		nBox.set(2465468068405565.54890450808465);
		
		System.out.println(iBox.get());
		System.out.println(dBox.get());
		System.out.println(nBox.get());
	}

}
